export class TodoFilterType {
    public name: string;
    public isHidden?: boolean;
}