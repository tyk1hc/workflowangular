export enum TodoCategory {
    house, bureaucracy
}
